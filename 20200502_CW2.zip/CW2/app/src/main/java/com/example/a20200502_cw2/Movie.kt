package com.example.a20200502_cw2

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "movies_table")
data class Movies (

    @PrimaryKey(autoGenerate = true )
    val id: Int = 0,

    val title: String,
    val year:String,
    val rating : String,
    val releaseDate: String,
    val runTime : String,
    val genre : String,
    val director : String,
    val writer : String,
    val actors : String,
    val plot : String,
    )