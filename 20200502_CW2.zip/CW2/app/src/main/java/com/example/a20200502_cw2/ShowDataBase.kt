package com.example.a20200502_cw2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.TextView
import androidx.room.Room
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class ShowDataBase : AppCompatActivity() {

    private lateinit var showMv : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_data_base)
        //initializing the Room Database and MovieDao
        val movieDataB = Room.databaseBuilder(this,MovieDatabase::class.java,
            "movie Database").build()
        val movieDao = movieDataB.movieDao()
        showMv = findViewById(R.id.tvMovies)

        runBlocking {
            launch {
                val movies:MutableList<Movies> = movieDao.getMovies() as MutableList<Movies>

                for (m in movies){
                    showMv.append("\n${m.id}.  ${m.title}"+
                            "\nYear : ${m.year}" +
                            "\nRated : ${m.rating}" +
                            "\nReleased : ${m.releaseDate}" +
                            "\nRuntime : ${m.runTime}" +
                            "\nGenre : ${m.genre}" +
                            "\nDirector : ${m.director}" +
                            "\nWriter : ${m.writer}" +
                            "\nActors : ${m.actors}" +
                            "\nPlot : ${m.plot}\n\n")
                }
            }
        }
        if (savedInstanceState == null){
            if (savedInstanceState != null) {
                showMv.text = savedInstanceState.getString("rMovie")
            }
        }

    }
    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)

        outState.putString("rMovie",showMv.text.toString())
    }

}


