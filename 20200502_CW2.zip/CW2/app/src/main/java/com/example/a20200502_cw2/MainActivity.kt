package com.example.a20200502_cw2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.StringBuilder
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    var allMovies = java.lang.StringBuilder()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtSearchR = findViewById<EditText>(R.id.tvAPIsearch)
        val tvActor = findViewById<TextView>(R.id.tvAinput)

        //initializing the RoomDatabase and MovieDao
        val movieDataB = Room.databaseBuilder(this,MovieDatabase::class.java,
            "movie Database").build()
        val movieDao = movieDataB.movieDao()
        var movies = mutableListOf<Movies>()
        addingMovies(movies)


        //button to add movies to the database that is already hardcoded
        val btnAddDB = findViewById<Button>(R.id.btnAdd)
        btnAddDB.setOnClickListener {
            runBlocking {
                launch {
                    movieDao.addMovies(movies)

                }
            }

            val intent = Intent(this,ShowDataBase::class.java)
            startActivity(intent)
        }

        //button to search actors in the hardcoded data
        val btnSearchA = findViewById<Button>(R.id.btnSearchA)
        btnSearchA.setOnClickListener {
            val intent2 = Intent(this,SearchActor::class.java)
            startActivity(intent2)
        }
        //button to search for movies from the WEB SERVICE (API)
        val btnSearchM = findViewById<Button>(R.id.btnSearchM)
        btnSearchM.setOnClickListener {
            val intent3 = Intent(this,SearchMovie::class.java)
            startActivity(intent3)
        }


        val btnSearchAPI = findViewById<Button>(R.id.btnAPI)
        val btnSeAPI = findViewById<Button>(R.id.btnSearch2)
        txtSearchR.visibility = View.INVISIBLE
        btnSeAPI.visibility = View.INVISIBLE
    //when the btnSearchAPI clicked fields will be visible
        btnSearchAPI.setOnClickListener {
            btnSearchAPI.visibility = View.INVISIBLE
            txtSearchR.visibility = View.VISIBLE
            btnSeAPI.visibility = View.VISIBLE
            //after the button is pressed it checks the userinput with the webservice and shows the movie name
            btnSeAPI.setOnClickListener {
                tvActor.setText("")
                var textInput = txtSearchR.text.toString().trimStart().trimEnd()
                if (textInput.trim().isEmpty()){
                    Toast.makeText(this@MainActivity,"Enter Valid Text",Toast.LENGTH_LONG).show()
                    val warning = "Enter Valid Text"
//                    tvActor.text = warning
                }else {
                    var stringBuilder = StringBuilder()
                    var title = "*$textInput*"
                    val url_string = "https://www.omdbapi.com/?s=$title&apikey=7cf6f8ce"
                    val url = URL(url_string)
                    val con: HttpURLConnection = url.openConnection() as HttpURLConnection
                    runBlocking {
                        launch {
                            withContext(Dispatchers.IO) {
                                var bufferedReader = BufferedReader(InputStreamReader(con.inputStream))
                                var line: String? = bufferedReader.readLine()
                                while (line != null) {
                                    stringBuilder.append(line + "\n")
                                    line = bufferedReader.readLine()
                                }
                                parseJSON(stringBuilder)
                            }
                        }
                    }
                    tvActor.setText(allMovies)
                }
            }
        }
    }

    private fun parseJSON(stb: java.lang.StringBuilder){
        val json = JSONObject(stb.toString())
        try {
            val jsonArray : JSONArray = json.getJSONArray("Search")
            for (item in 0 until jsonArray.length()){
                val arrMovie = jsonArray[item] as JSONObject
                val title = arrMovie["Title"] as String
                allMovies.append("\"$title\"\n")

            }

        }catch (e: Exception){
//            Toast.makeText(this@MainActivity,"Enter a Correct Movie Title",Toast.LENGTH_LONG).show()
            allMovies.append("Enter Correct Movie Name")
        }
    }
    //Hardcoded Movie data that will appear when the add to database button is clicked
    private fun addingMovies(movies: MutableList<Movies>) {

        movies.add(Movies(1,"The Shawshank Redemption","1994","R","14-10-1994","142min","Drama","Frank Darabont","Stephen King, Frank Darabont","Tim Robbins, Morgan Freeman, Bob Gunton","Two imprisoned men bond over a number of years, finding solac and eventual redemption through acts of common decency."))
        movies.add(Movies(2,"Batman: The Dark Knight Returns, Part 1","2012","PG-13","25-9-2012","76min","Animation, Action, Crime, Drama, Thriller","Jay Oliva","Bob Kane,Frank Miller,Klaus Janson,Bob\n" +
                "Goodman","Peter Weller, Ariel Winter, David Selby, Wade Williams","Batman has not been seen for ten years. A new breed\n" +
                "of criminal ravages Gotham City, forcing 55-year-old Bruce Wayne back\n" +
                "into the cape and cowl. But, does he still have what it takes to fight\n" +
                "crime in a new era?"))
        movies.add(Movies(3,"The Lord of the Rings: The Return of the King","2003","PG-13","17-12-2003","201min","Action, Adventure, Drama","Peter Jackson","J.R.R. Tolkien, Fran Walsh, Philippa Boyens","Elijah Wood, Viggo Mortensen, Ian McKellen","Gandalf and Aragorn lead the World of Men against Sauron's\n" +
                "army to draw his gaze from Frodo and Sam as they approach Mount Doom\n" +
                "with the One Ring"))
        movies.add(Movies(4,"Inception","2010","PG-13","16-07-2010","148min","Action, Adventure, Sci-Fi","Christopher Nolan","Christopher Nolan","Leonardo DiCaprio, Joseph Gordon-Levitt, Elliot Page","A thief who steals corporate secrets through the use of\n" +
                "dream-sharing technology is given the inverse task of planting an idea\n" +
                "into the mind of a C.E.O., but his tragic past may doom the project\n" +
                "and his team to disaster"))
        movies.add(Movies(5,"The Matrix","1999","R","31-03-1999","136min","Action, Sci-Fi","Lana Wachowski, Lilly Wachowski","Lilly Wachowski, Lana Wachowski","Keanu Reeves, Laurence Fishburne, Carrie-Anne Moss","When a beautiful stranger leads computer hacker Neo to a\n" +
                "forbidding underworld, he discovers the shocking truth--the life he\n" +
                "knows is the elaborate deception of an evil cyber-intelligence"))

    }


}