package com.example.a20200502_cw2

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface MovieDao {

        @Insert(onConflict = OnConflictStrategy.REPLACE)
        suspend fun addMovies(movie:MutableList<Movies>)

        @Query("SELECT * FROM movies_table")
        suspend fun getMovies(): List<Movies>

        @Query("SELECT * from movies_table where lower(actors) LIKE lower('%'|| :actorName ||'%')")
        suspend fun searchActor(actorName : String):List<Movies>

//        @Query("DELETE FROM movies_table")
//        fun delete()

        @Insert(onConflict = OnConflictStrategy.REPLACE)
        suspend fun addMovie(movie: Movies)

    }
