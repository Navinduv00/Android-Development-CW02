package com.example.a20200502_cw2

import android.graphics.Movie
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.room.Room
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class SearchActor : AppCompatActivity() {
    lateinit var searchResult : TextView
    private lateinit var btnSearch : Button
    private lateinit var actorInput : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_actor)
        searchResult = findViewById(R.id.tvSearchAR)
        btnSearch = findViewById(R.id.btnSearchA2)
        actorInput  = findViewById(R.id.actorInput)

        //when the button is clicked it checks the Userinput with the hardcoded movie data
        btnSearch.setOnClickListener {
            var actorName = actorInput.text.toString()
            searchResult.text = ""

            val movieDataB = Room.databaseBuilder(this,MovieDatabase::class.java,
                "movie Database").build()
            val movieDao = movieDataB.movieDao()

            runBlocking {
                launch {

                    // Getting the movies to a list
                    val movies: List<Movies> = movieDao.searchActor(actorName)

                    for (movie in movies){
                        searchResult.append("Title : ${movie.title}" +
                                "\nYear : ${movie.year}" +
                                "\nRated : ${movie.rating}" +
                                "\nReleased : ${movie.releaseDate}" +
                                "\nRuntime : ${movie.runTime}" +
                                "\nGenre : ${movie.genre}" +
                                "\nDirector : ${movie.director}" +
                                "\nWriter : ${movie.writer}" +
                                "\nActors : ${movie.actors}" +
                                "\nPlot : ${movie.plot}\n\n")
                    }
                }
            }

        }

    }
    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
        println(searchResult.text.toString())
        outState.putString("movie",searchResult.text.toString())
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)

        val getDetails = savedInstanceState.getString("movie","no Data")
        println(getDetails)
        searchResult.text=getDetails
    }
}