package com.example.a20200502_cw2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.Exception
import java.lang.StringBuilder
import java.net.HttpURLConnection
import java.net.URL

class SearchMovie : AppCompatActivity() {

    private lateinit var getMoviebtn : Button
    private lateinit var saveMoviebtn : Button
    private lateinit var txtMovieDetails : TextView
    private lateinit var userInput : EditText
    private lateinit var movieName : String

    lateinit var title: String
    lateinit var year: String
    lateinit var rated: String
    lateinit var released: String
    lateinit var genre: String
    lateinit var writer: String
    lateinit var actors: String
    lateinit var plot: String
    lateinit var runtime: String
    lateinit var director:String

    var allMovies = java.lang.StringBuilder()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_movie)

        getMoviebtn = findViewById(R.id.btnSearchMovie)
        saveMoviebtn = findViewById(R.id.btnSaveDB)
        txtMovieDetails = findViewById(R.id.tvOutput)
        userInput = findViewById(R.id.movieInput)

        val movieDataB = Room.databaseBuilder(this,MovieDatabase::class.java, "movie Database").build()
        val movieDao = movieDataB.movieDao()

        getMoviebtn.setOnClickListener {
            allMovies.clear()
            movieName = userInput.getText().toString()
                getDataFromAPI(movieName)
            if (movieName!=userInput.getText().toString()){
                txtMovieDetails.text = allMovies

            }else{
                  txtMovieDetails.text = allMovies
                Toast.makeText(this@SearchMovie,"Movie found",Toast.LENGTH_LONG).show()

            }

        }
        saveMoviebtn.setOnClickListener {
            allMovies.clear()
            movieName = userInput.getText().toString()
            getDataFromAPI(movieName)
            txtMovieDetails.text = allMovies

            if (allMovies.toString() == "Movie Not Found"){
                Toast.makeText(this@SearchMovie,"Movie not found",Toast.LENGTH_LONG).show()

                txtMovieDetails.text = "No Movie Data to Save"
            }else {

                runBlocking {
                    launch {
                        val mov = Movies(
                            title = title,
                            year = year,
                            rating = rated,
                            releaseDate = released,
                            runTime = runtime,
                            genre = genre,
                            director = director,
                            writer = writer,
                            actors = actors,
                            plot = plot
                        )

//                        userDao.addMovies(mov)

                        val moviList: List<Movies> = movieDao.getMovies()
                        if (checkingForMovieInDB(mov,moviList)){
//                            txtMovieDetails.text = "Movie is already in the Database"
                            Toast.makeText(this@SearchMovie,"Movie is already in the Database",Toast.LENGTH_LONG).show()
                        }else{
                            movieDao.addMovie(mov)
                            val moviesList: List<Movies> = movieDao.getMovies()
                            for (m in moviesList) {
                                txtMovieDetails.append("Title : ${m.title}\n")
                            }
                        }

                    }
                }
            }
        }
        if (savedInstanceState != null){
                txtMovieDetails.text = savedInstanceState.getString("rMovie")
            }

    }


    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)

        outState.putString("rMovie",txtMovieDetails.text.toString())
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)

        val getDetails = savedInstanceState.getString("rMovie","")
        txtMovieDetails.text=getDetails
    }

    fun getDataFromAPI(name: String){
        var stringBuilder = StringBuilder()
        val url_string = "https://www.omdbapi.com/?t=$name&apikey=7cf6f8ce"
        val url = URL(url_string)
        println("work")

        val con: HttpURLConnection = url.openConnection() as HttpURLConnection
        runBlocking {
            launch {
                withContext(Dispatchers.IO) {
                    var bufferedReader = BufferedReader(InputStreamReader(con.inputStream))
                    var line: String? = bufferedReader.readLine()
                    while (line != null) {
                        stringBuilder.append(line + "\n")
                        line = bufferedReader.readLine()
                    }
                    parseJSON(stringBuilder)
                }
            }
        }
    }
    suspend fun parseJSON(stb: java.lang.StringBuilder) {
// this contains the full JSON returned by the Web Service
        val json = JSONObject(stb.toString())
// Information about all the books extracted by this function

        try {
            title = json["Title"] as String
            year = json["Year"] as String
            rated = json["Rated"] as String
            released = json["Released"] as String
            runtime = json["Runtime"] as String
            genre = json["Genre"] as String
            director = json["Director"] as String
            writer = json["Writer"] as String
            actors = json["Actors"] as String
            plot = json["Plot"] as String
            allMovies.append(
                "Title :  \"$title\" " +
                        "\nYear :  $year" +
                        "\nRated :  $rated" +
                        "\nReleased :  $released" +
                        "\nRuntime :  $runtime" +
                        "\nGenre :  $genre" +
                        "\nDirector :  $director" +
                        "\nWriter :  $writer" +
                        "\nActors :  $actors\n" +
                        "\nPlot :  \"$plot\" \n\n"
            )
        } catch (e: Exception) {
            allMovies.append("Movie Not Found")
        }

    }
        private fun checkingForMovieInDB(movie: Movies, movieList: List<Movies>): Boolean{
        for (mov in movieList){
            if (movie.title == mov.title){
                return true
            }
        }
        return false
    }



}